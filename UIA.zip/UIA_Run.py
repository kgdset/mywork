# -*- coding: utf-8 -*-
import os
import time
import datetime
import subprocess
import threading
import sys 
currentdir = os.getcwd()#获取当前路径 
logdir=os.path.join(currentdir,'Log')
if not os.path.exists(logdir):
    os.mkdir(logdir)

testjar="GosTest.jar"
logPath=os.path.join(logdir,'log.txt')#log文件
timeout = 5*600000
logTag=''
logid=0
reportPath=''
#创建并写入report文件
def write_txt(str):

    f = open(reportPath,'a')  
    f.write(str)
    f.close()
    

def KillPID(pid): 
    # Use system cmd TaskKill /T 终止指定的进程和由它启用的子进程 
    # /F 强制终止 
    # /IM 指定终止进程的映像名称 
    # /PID 指定要终止进程的PID 
    cmd='TaskKill /T /F /PID %s' % (pid) 
    #print '进程名称:',key 
    os.popen(cmd) # carry out the cmd 

#cmd执行
def timout_command(command, timeout):
    #print command
    start = datetime.datetime.now()
    process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
    while process.poll() is None:
        time.sleep(1)
        now = datetime.datetime.now()
        if (now - start).seconds > timeout :            
            os.kill(process.pid, signal.SIGKILL)
            os.waitpid(-1, os.WNOHANG)
            return 'timeout'
    output = process.stdout.read()
    process.stdout.close()
    return output

#抓取Log
def generate_log(tag,CaseName):
    global logid
    print "Gether Logs: BEGIN"
    print "Gether Tag: ["+tag+"]"
    
    command="adb logcat -v time Tag>"+os.path.join(logdir,CaseName)+".txt"
    logid=os.getpid()
    print "Run_Process: ID=["+str(logid)+"]"
    os.system(command)

#case执行
def run_testcase(testCase,reportPath):
    
    result={}
    threads = threading.Thread(target=generate_log,args=(logTag,testCase))
    threads.start()
    time.sleep(2)
    print 'TC_Running: ['+testCase+']'
    result["result"]=timout_command("adb shell uiautomator runtest "+testjar+" -c "+testCase+"",timeout)
    
    if "OK" in result["result"]:
        result["state"]="pass"
    else:
        result["state"]="faild"
    print 'TCReport: ['+testCase+']===>'+result['state']+''
    #print 'TestLog '+result['result']+'' 
    write_txt(result['result'])
    print 'End TC: ['+testCase+']'
    print "Kill_Process: ID=["+str(logid)+"]"
    print "Finish_TC: ID=["+testCase+"]"
    start = datetime.datetime.now()
    print "Finish_Time: ID=["+str(start)+"]\n"
    KillPID(logid)


testCase=sys.argv[1]
reportPath=sys.argv[2]
run_testcase(testCase,reportPath)
