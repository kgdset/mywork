# -*- coding: utf-8 -*-
import os
import time
import datetime
import subprocess
currentdir = os.getcwd()
reoprtdir=os.path.join(currentdir,'Report')
testjar=os.path.join(currentdir,'GosTest.jar')
cvtdir=os.path.join(currentdir,'cvt')
if not os.path.exists(reoprtdir):
    os.mkdir(reoprtdir)
screenshotdir=os.path.join(currentdir,'screenshots')
if not os.path.exists(screenshotdir):
    os.mkdir(screenshotdir)
starttime = datetime.datetime.now()
starttime=str(starttime.year)+str(starttime.month)+str(starttime.day)+str(starttime.hour)+str(starttime.minute)

runpy=os.path.join(currentdir,'UIA_Run.py')
txtpath=os.path.join(currentdir,'testtask.txt')#测试任务配置文件
reportPath=os.path.join(reoprtdir,'report_'+starttime+'.txt')#测试报告原始文件
cvtjar=os.path.join(cvtdir,'uiautomator2junit-0.2.jar')#报告转换用到的jar包
testTask=[]
#读取测试任务文件
def red_txt(txtpath):
    f = open(txtpath, "r")
    
    while True:  
        line = f.readline()  
        if line:  
            testTask.append(line.replace('\n',''))
        else:  
            break 
    f.close()
    return testTask
def pushjar():
    command="adb push "+testjar+" /data/local/tmp/"
    process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
    process.communicate()
def pullimg():
    command="adb pull /data/local/tmp/screenshots "+screenshotdir+""
    process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
    process.communicate()
#转换测试报xml
def cvt_report():
    command="java -jar "+cvtjar+" "+reportPath+""
    process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
    process.communicate()
#遍历执行测试任务        
def run_testsuit(): 
    red_txt(txtpath)
    pushjar()
    for testcase in testTask:
        start = datetime.datetime.now()
        print 'Begin TC ['+testcase+']'
        print 'Begin time ['+str(start)+']'
        command="python "+runpy+" "+testcase+" "+reportPath+""
        os.system(command)
    print '....................Generate a report.......................'
    cvt_report()
    print '....................save screenshots.......................'
    pullimg()
    print '************************************************************'
    print '********************All Test Finished***********************'
    print '************************************************************'
run_testsuit()
